# Option 1 - Safe Bootstrap (Existing-first, Create-explicit)

This package matches your Option 1 diagram:
- A common Terraform repo controls RG/Capacity/Workspaces discovery.
- It creates downstream Fabric items only inside the JOBS workspace via your existing modules.

## Key safety rules
- RG + Capacity are ALWAYS referenced (data sources only). Never created here.
- Workspaces are either:
  - referenced (create_* = false), or
  - created explicitly (create_* = true)
- Workspace creation is blocked in PROD by default.
- prevent_destroy is enabled for created workspaces and RBAC resources.

## Run (DEV)
```bash
terraform init -backend-config="key=nip-fabric/dev/terraform.tfstate"
terraform plan  -var-file=env/dev.tfvars
terraform apply -var-file=env/dev.tfvars
```

## Bootstrap (first-time env)
Set create_* flags to true in the env tfvars for the workspaces you want created.
Example:
- create_jobs_workspace = true
- create_df_workspace = true
- create_reporting_workspace = true

If a workspace already exists and create_* is true, Azure will reject creation (safe failure).

## Modules
This expects your repo layout:
- ../../modules/lakehouses
- ../../modules/artifacts

If your paths differ, change the `source =` lines.
